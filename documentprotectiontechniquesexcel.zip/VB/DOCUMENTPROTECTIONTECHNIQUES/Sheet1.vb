﻿'***************************************************************************
'
'         Copyright (c) Microsoft Corporation. All rights reserved.
'
'    This code sample is provided "AS IS" without warranty of any kind.
'
'***************************************************************************
Public Class Sheet1

#Region "Properties"

    ''' <summary>
    ''' Returns whether the sheet is protected.
    ''' </summary>
    ''' <value>
    ''' Returns true if the sheet is protected,
    ''' or false if it is not.
    ''' </value>
    Friend ReadOnly Property IsProtected() As Boolean
        Get
            Return (Me.ProtectContents)
        End Get
    End Property

#End Region

#Region "Methods"
    ''' <summary>
    ''' Protects the sheet with no password.
    ''' </summary>
    Friend Sub ProtectSheet()
        ' Ensures that the sheet is not already protected.
        If (Me.IsProtected) Then
            Throw New InvalidOperationException()
        End If

        ' Protects the sheet so that it can only be read and 
        ' unprotected with no password.
        Me.Protect()
    End Sub

    ''' <summary>
    ''' Unprotects the sheet with no password.
    ''' </summary>
    Friend Sub UnprotectSheet()
        ' Ensures that the document is not already unprotected.
        If (Not (Me.IsProtected)) Then
            Throw New InvalidOperationException()
        End If

        ' Unprotects the sheet with no password.
        Me.Unprotect()
    End Sub

#End Region

    ''' <summary>
    ''' Handles the Startup event for the sheet. When the event fires, 
    ''' the sheet will be unprotected first, customerListObject will be 
    ''' bound to customerBindingSource, the sheet will be protected 
    ''' afterwards.
    ''' </summary>
    ''' <param name="sender">Unused.</param>
    ''' <param name="e">Unused.</param>
    ''' <remarks></remarks>
    Private Sub Sheet1_Startup(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Startup
        Try
            ' Unprotects sheet
            Me.UnprotectSheet()

            ' Creates ListObject and binds to BindingSource.
            customerListObject.AutoSetDataBoundColumnHeaders = True
            customerListObject.SetDataBinding(Globals.ThisWorkbook.custBindingSource, "", "firstName", "lastName", "userName")
        Finally
            ' Protects sheet
            Me.ProtectSheet()
        End Try
    End Sub

    Private Sub Sheet1_Shutdown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shutdown

    End Sub

End Class
